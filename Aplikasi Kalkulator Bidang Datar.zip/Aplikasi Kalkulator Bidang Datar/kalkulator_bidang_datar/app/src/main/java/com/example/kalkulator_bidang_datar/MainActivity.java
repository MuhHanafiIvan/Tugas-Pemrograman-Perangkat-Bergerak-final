package com.example.kalkulator_bidang_datar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText txtPAD, txtLT;
    Button btnPersegi, btnSegitiga, btnLingkaran;
    TextView txtLuas, txtKeliling;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Kalkulator Bidang Datar");

        txtPAD = findViewById(R.id.txtPAD);
        txtLT = findViewById(R.id.txtLT);
        btnPersegi = findViewById(R.id.btnPersegi);
        btnSegitiga = findViewById(R.id.btnSegitiga);
        btnLingkaran = findViewById(R.id.btnLingkaran);
        txtLuas = findViewById(R.id.txtLuas);
        txtKeliling = findViewById(R.id.txtKeliling);

        btnPersegi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double panjang = Double.parseDouble(txtPAD.getText().toString());
                double lebar = Double.parseDouble(txtLT.getText().toString());
                double luas = panjang * lebar;
                double keliling = 2 * (panjang + lebar);
                txtLuas.setText(String.valueOf(luas));
                txtKeliling.setText(String.valueOf(keliling));
            }
        });

        btnSegitiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double alas = Double.parseDouble(txtPAD.getText().toString());
                double tinggi = Double.parseDouble(txtLT.getText().toString());
                double luas = 0.5 * alas * tinggi;
                double keliling = Math.sqrt(Math.pow(alas,2) + Math.pow(tinggi,2)) + alas + tinggi;
                txtLuas.setText(String.valueOf(luas));
                txtKeliling.setText(String.valueOf(keliling));
            }
        });

        btnLingkaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double diameter = Double.parseDouble(txtPAD.getText().toString());
                double jari2 = diameter/2;
                double luas = 3.14 * Math.pow(jari2,2);
                double keliling = 3.14 * diameter;
                txtLuas.setText(String.valueOf(luas));
                txtKeliling.setText(String.valueOf(keliling));
            }
        });

    }
}