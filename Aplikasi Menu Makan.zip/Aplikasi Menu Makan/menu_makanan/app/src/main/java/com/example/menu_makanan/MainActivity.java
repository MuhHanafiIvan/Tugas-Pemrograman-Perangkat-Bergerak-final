package com.example.menu_makanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvMakanan;
    private MakananRecyclerViewAdapter makananRecyclerViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Menu Makanan - Ivan");

        rvMakanan = findViewById(R.id.rvMakanan);
        rvMakanan.setLayoutManager(new LinearLayoutManager(this));

        makananRecyclerViewAdapter = new MakananRecyclerViewAdapter();
        rvMakanan.setAdapter(makananRecyclerViewAdapter);

        setData();
    }

    private void setData() {
        List<Makanan> dummyData = DummyMakanan.makananList();
        makananRecyclerViewAdapter.updateData(dummyData);
    }
}