package com.example.menu_makanan;

import java.util.ArrayList;
import java.util.List;

public class DummyMakanan {
    public static List<Makanan> makananList() {
        Makanan pecel_lele = new Makanan("Pecel Lele", "Pecel + Lele Goreng", 15000, "x");
        Makanan nasi_goreng = new Makanan("Nasi Goreng", "Nasi di Goreng", 18000, "x");
        Makanan ayam_geprek = new Makanan("Ayam Geprek", "Ayam di Geprek", 20000, "x");
        Makanan tahu_bulat = new Makanan("Tahu Bulat", "Tahu di Goreng Dadakan", 5000, "x");
        Makanan kari_ayam = new Makanan("Kari Ayam", "Kari rasa Ayam", 21000, "x");

        List<Makanan> makananList = new ArrayList<>();

        makananList.add(pecel_lele);
        makananList.add(nasi_goreng);
        makananList.add(ayam_geprek);
        makananList.add(tahu_bulat);
        makananList.add(kari_ayam);

        return makananList;
    }
}
