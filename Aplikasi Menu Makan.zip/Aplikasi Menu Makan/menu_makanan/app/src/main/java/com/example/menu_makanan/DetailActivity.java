package com.example.menu_makanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    TextView txt_nama, txt_harga, txt_deskripsi;
    LinearLayoutCompat layoutdetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        setTitle("Detail Menu Makanan");

        txt_nama = findViewById(R.id.nama);
        txt_harga = findViewById(R.id.harga);
        txt_deskripsi = findViewById(R.id.deskripsi);

        layoutdetail = findViewById(R.id.detailNama);

        Intent intent = getIntent();
        String nama = intent.getStringExtra("nama");
        String harga = intent.getStringExtra("harga");
        String deskripsi = intent.getStringExtra("deskripsi");

        txt_nama.setText(String.valueOf(nama));
        txt_harga.setText(String.valueOf(harga));
        txt_deskripsi.setText(String.valueOf(deskripsi));
    }
}