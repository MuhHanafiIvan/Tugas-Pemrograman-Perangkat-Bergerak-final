package com.example.menu_makanan;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MakananRecyclerViewAdapter extends RecyclerView.Adapter<MakananRecyclerViewAdapter.MakananViewHolder> {
    private List<Makanan> makananList = new ArrayList<>();

    @NonNull
    @Override
    public MakananViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);
        return new MakananViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MakananViewHolder holder, int position) {
        Makanan makanan = makananList.get(position);

        holder.tvMakananNama.setText(makanan.getNama());
        holder.tvMakananHarga.setText(String.valueOf(makanan.getHarga()));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), DetailActivity.class);
                intent.putExtra("nama",makanan.getNama());
                intent.putExtra("harga",String.valueOf(makanan.getHarga()));
                intent.putExtra("deskripsi",makanan.getDeskripsi());
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return makananList.size();
    }

    public void updateData(List<Makanan> groceryList) {
        this.makananList = groceryList;
        notifyDataSetChanged();
    }

    static class MakananViewHolder extends RecyclerView.ViewHolder {

        private TextView tvMakananNama;
        private TextView tvMakananHarga;

        public MakananViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMakananNama = itemView.findViewById(R.id.namaMakanan);
            tvMakananHarga = itemView.findViewById(R.id.hargaMakanan);
        }
    }
}
