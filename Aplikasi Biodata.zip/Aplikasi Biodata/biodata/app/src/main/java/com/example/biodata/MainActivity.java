package com.example.biodata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnAlamat, btnTelepon, btnEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("BiodataKu - Ivan");

        btnAlamat = findViewById(R.id.btnAlamat);
        btnAlamat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent  = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.google.com/maps/place/7%C2%B032'08.1%22S+110%C2%B038'18.7%22E/@-7.5355833,110.6379806,19z/data=!3m1!4b1!4m6!3m5!1s0x0:0x0!7e2!8m2!3d-7.5355732!4d110.6385208"));
                startActivity(intent);
            }
        });

        btnTelepon = findViewById(R.id.btnTelepon);
        btnTelepon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent  = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:082220178913"));
                startActivity(intent);
            }
        });

        btnEmail = findViewById(R.id.btnEmail);
        btnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent  = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:111202013115@mhs.dinus.ac.id"));
                startActivity(intent);
            }
        });
    }
}